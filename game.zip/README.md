# Project KLOQOWEJ Prototype

Fun, engaging and interactive app for kids to learn the Mi'kmaq language.

***Please be aware that this is just a prototype and does not represent the final product.***

## credits:

Background art: [Background vector created by vectorpouch - www.freepik.com](https://www.freepik.com/vectors/background)
